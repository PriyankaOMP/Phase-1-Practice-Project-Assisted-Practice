package practicephase1;

public class TypeCasting {
	public static void implicit() {
		System.out.println("this is an example of implicit or widenning typecasting");
		int a= 10;
	    long b=a;
	    float c=b;
	    System.out.println("Before conversion : "+a);
	    System.out.println("To long conversion : "+b);
	    System.out.println("To float conversion : "+c);
	    System.out.println("-----------------------------------------------");
		
	}
	public static void explicit() {
		System.out.println("this is an example of explicit or narrowing typecasting");
		double a = 9.00;
		long b=(long)a;
		int c = (int)b;
		System.out.println("Before conversion : "+a);
	    System.out.println("To long conversion : "+b);
	   System.out.println("To float conversion : "+c);
	    System.out.println("-----------------------------------------------");
	}
	public static void main(String args[]) {
		implicit();
		explicit();
	}
}